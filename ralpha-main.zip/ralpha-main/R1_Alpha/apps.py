from django.apps import AppConfig


class R1AlphaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'R1_Alpha'
